import React, { Component } from 'react';

// Import Images
import teamMember1 from '../../images/team/member1.jpg';
import teamMember2 from '../../images/team/member2.jpg';
import teamMember3 from '../../images/team/member3.jpg';
import ptImg1 from '../../images/shap/trangle-orange.png';

const teamMembers = [
	{
		name: 'Dr. Addition Smith',
		specialization: 'Dentist',
		image: teamMember1,
		socialMedia: [
			{ platform: 'Twitter', link: 'https://twitter.com/' },
			{ platform: 'LinkedIn', link: 'https://www.linkedin.com/' },
			{ platform: 'Instagram', link: 'https://www.instagram.com/' },
		],
	},
	{
		name: 'Dr. Mahfuz Riad',
		specialization: 'Chiropractor',
		image: teamMember2,
		socialMedia: [
			{ platform: 'Twitter', link: 'https://twitter.com/' },
			{ platform: 'LinkedIn', link: 'https://www.linkedin.com/' },
			{ platform: 'Instagram', link: 'https://www.instagram.com/' },
		],
	},
	{
		name: 'Dr. David Benjamin',
		specialization: 'Cardiologist',
		image: teamMember3,
		socialMedia: [
			{ platform: 'Twitter', link: 'https://twitter.com/' },
			{ platform: 'LinkedIn', link: 'https://www.linkedin.com/' },
			{ platform: 'Instagram', link: 'https://www.instagram.com/' },
		],
	},
];

class TeamSection extends Component{
	render(){
		return(
			<>
				
				<section className="section-area section-sp3 team-wraper">
					<div className="container">
						<div className="heading-bx text-center">
							<h6 className="title-ext text-secondary">Our Doctor</h6>
							<h2 className="title">Meet Best Doctors</h2>
						</div>
						<div className="row justify-content-center">
							{teamMembers.map((teamMember, index) => (
								<div key={index} className="col-lg-4 col-sm-6 mb-30">
									<div className="team-member">
										<div className="team-media">
											<img src={teamMember.image} alt={teamMember.name} />
										</div>
										<div className="team-info">
											<div className="team-info-content">
												<h4 className="title">{teamMember.name}</h4>
												<span className="text-secondary">{teamMember.specialization}</span>
											</div>
											<ul className="social-media mt-3">
												{teamMember.socialMedia.map((social, index) => (
													<li key={index}>
														<a rel="noreferrer" target="_blank" href={social.link}>
															<i className={`fab fa-${social.platform.toLowerCase()}`} />
														</a>
													</li>
												))}
											</ul>
										</div>
									</div>
								</div>
							))}
						</div>
					</div>
					<img className="pt-img1 animate1" src={ptImg1} alt=""/>
				</section>
				
			</>
		);
	}
}

export default TeamSection;